package elections;

public class IllegalObjectException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public IllegalObjectException(String message) {
		super(message);

	}

}
